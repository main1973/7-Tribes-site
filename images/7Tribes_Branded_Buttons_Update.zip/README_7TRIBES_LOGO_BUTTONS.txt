7Tribes — Loop, Connect, Nuru button icons

Target repository: main1973/7-Tribes-site
Prepared update: apply_7tribes_brand_buttons.py

The script modifies ONLY:
  js/unified-menu.js
  css/unified-menu.css

It adds small logo badges to matching Loop, Connect, and Nuru buttons across the public site and the unified menu. Existing destinations, text, login and payment behavior stay unchanged. It also adds Nuru to the shared Community menu.

To apply from the repository root:
  python3 apply_7tribes_brand_buttons.py

The logo icons are sourced from the associated sites:
  Loop: https://loop.7trb.com/favicon.png
  Connect: https://connect.7trb.com/favicon.ico
  Nuru: https://nuruai.org/favicon.ico

Each icon has an initial-letter fallback if it cannot load. Nuru's favicon was not independently verified; replace it with an official supplied Nuru logo if necessary.

After applying: review the diff, commit the two files to GitHub, and check 7trb.com in Chrome and the Nuru browser at phone width. Do not alter authentication, payments or deployment settings.
