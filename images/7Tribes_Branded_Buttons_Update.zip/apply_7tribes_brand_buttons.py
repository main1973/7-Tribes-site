#!/usr/bin/env python3
"""Add Loop, Connect and Nuru brand badges to the existing shared 7Tribes menu.

Usage from the root of main1973/7-Tribes-site:
    python3 apply_7tribes_brand_buttons.py

Only modifies js/unified-menu.js and css/unified-menu.css.
No page, auth, wallet, or payment behavior is changed.
"""
from pathlib import Path
import sys

ROOT = Path.cwd()
JS = ROOT / 'js/unified-menu.js'
CSS = ROOT / 'css/unified-menu.css'
if not JS.is_file() or not CSS.is_file():
    sys.exit('Run this script from the root of main1973/7-Tribes-site (the js/ and css/ files must exist).')

script = JS.read_text(encoding='utf-8')
styles = CSS.read_text(encoding='utf-8')
MARKER = '/* BRANDED BUTTONS: Loop / Connect / Nuru */'
if MARKER in script or MARKER in styles:
    sys.exit('Brand icons have already been installed. No changes made.')

old_community = "['Loop','https://loop.7trb.com'], ['Connect','https://connect.7trb.com'],\n      ['Telegram','https://t.me/SevenTribeowner']"
new_community = "['Loop','https://loop.7trb.com'], ['Connect','https://connect.7trb.com'],\n      ['Nuru','https://nuruai.org/'], ['Telegram','https://t.me/SevenTribeowner']"
if script.count(old_community) != 1:
    sys.exit('The Community navigation links have changed; no files modified. Inspect js/unified-menu.js.')
script = script.replace(old_community, new_community)

old_quick = "var QUICK = [\n    ['Home','/'], ['Ecosystem','/ecosystem.html'], ['Learn','/learn.html'],\n    ['Loop','https://loop.7trb.com'], ['Connect','https://connect.7trb.com']\n  ];"
new_quick = "var QUICK = [\n    ['Home','/'], ['Ecosystem','/ecosystem.html'], ['Learn','/learn.html'],\n    ['Loop','https://loop.7trb.com'], ['Connect','https://connect.7trb.com'],\n    ['Nuru','https://nuruai.org/']\n  ];"
if script.count(old_quick) != 1:
    sys.exit('Quick navigation has changed; no files modified. Inspect js/unified-menu.js.')
script = script.replace(old_quick, new_quick)

addition = r'''    /* BRANDED BUTTONS: Loop / Connect / Nuru */
    // Existing platform favicons provide recognizable, real brand marks. The
    // accessible text stays visible; initials appear until each icon loads.
    function addPartnerButtonIcons() {
      var selector = [
        '#seven-nav-bar .seven-nav-quick a',
        '#mobile-drawer .drawer-section a',
        '.hero-actions a.btn', '.simple-actions a.btn',
        '.simple-card a', '.eco-feature-link', '.eco-role a',
        '.eco-final-actions a.btn', '.guide-actions a.btn',
        '.refresh-actions a.btn'
      ].join(',');
      var icons = {
        loop: {
          src: 'https://loop.7trb.com/favicon.png',
          initial: 'L', title: 'Loop'
        },
        connect: {
          src: 'https://connect.7trb.com/favicon.ico',
          initial: 'C', title: 'Connect'
        },
        nuru: {
          // Official Nuru website favicon. If unavailable, display the N badge.
          src: 'https://nuruai.org/favicon.ico',
          initial: 'N', title: 'Nuru'
        }
      };
      document.querySelectorAll(selector).forEach(function (anchor) {
        if (anchor.querySelector('.seven-partner-icon')) return;
        var url = anchor.href || '';
        var label = anchor.textContent || '';
        var key = null;
        if (/loop\.7trb\.com/i.test(url) && /loop/i.test(label)) key = 'loop';
        else if (/connect\.7trb\.com/i.test(url) && /connect/i.test(label)) key = 'connect';
        else if (/nuru/i.test(label) &&
          (/nuruai\.org/i.test(url) || /com\.alkebuleum\.nuru/i.test(url) || /how-nuru-works/i.test(url))) key = 'nuru';
        if (!key) return;
        var icon = icons[key];
        var badge = document.createElement('span');
        badge.className = 'seven-partner-icon seven-partner-' + key;
        badge.setAttribute('aria-hidden', 'true');
        var initial = document.createElement('span');
        initial.className = 'seven-partner-initial';
        initial.textContent = icon.initial;
        var image = document.createElement('img');
        image.alt = '';
        image.width = 22;
        image.height = 22;
        image.decoding = 'async';
        image.addEventListener('load', function () { badge.classList.add('seven-icon-loaded'); });
        image.addEventListener('error', function () { badge.classList.remove('seven-icon-loaded'); });
        badge.appendChild(initial);
        badge.appendChild(image);
        anchor.insertBefore(badge, anchor.firstChild);
        anchor.classList.add('seven-partner-link');
        image.src = icon.src;
      });
    }
    addPartnerButtonIcons();
'''
needle = "    var priorFocus = null;"
if script.count(needle) != 1:
    sys.exit('The menu initialization changed; no files modified. Check the location of `var priorFocus`.')
script = script.replace(needle, addition + '\n' + needle)

styles += r'''
/* BRANDED BUTTONS: Loop / Connect / Nuru */
/* Apply only to linked buttons and shared menu items. Text remains readable. */
.seven-partner-icon {
  display:inline-flex!important;
  align-items:center!important;
  justify-content:center!important;
  width:26px!important;
  height:26px!important;
  min-width:26px!important;
  flex:0 0 26px!important;
  padding:2px!important;
  margin:0 9px 0 0!important;
  vertical-align:middle!important;
  background:#26180b!important;
  border:1px solid rgba(231,184,82,.38)!important;
  border-radius:7px!important;
  color:#ffdd7a!important;
  box-sizing:border-box!important;
  font:900 14px/1 system-ui,Arial,sans-serif!important;
}
.seven-partner-icon .seven-partner-initial {display:inline!important;line-height:1!important}
.seven-partner-icon img {
  display:none!important;
  width:22px!important;height:22px!important;
  max-width:22px!important;max-height:22px!important;
  margin:0!important;padding:0!important;
  border:0!important;border-radius:4px!important;
  object-fit:contain!important;box-shadow:none!important;
}
.seven-partner-icon.seven-icon-loaded img {display:block!important}
.seven-partner-icon.seven-icon-loaded .seven-partner-initial {display:none!important}
/* Existing mobile button widths, background colors, and click targets remain untouched. */
#seven-nav-bar .seven-nav-quick .seven-partner-icon {width:23px!important;height:23px!important;min-width:23px!important;flex-basis:23px!important}
#seven-nav-bar .seven-nav-quick .seven-partner-icon img {width:19px!important;height:19px!important}
'''
# Keep writes atomic relative to validation.
if script.count('addPartnerButtonIcons();') != 1 or styles.count(MARKER) != 1:
    sys.exit('Validation failed. No files changed.')
JS.write_text(script, encoding='utf-8')
CSS.write_text(styles, encoding='utf-8')
print('Updated js/unified-menu.js and css/unified-menu.css.')
print('Loop and Connect use their existing site icons. Nuru uses its site favicon with a safe N fallback.')
print('Check Home, Ecosystem and the mobile menu in Chrome and Nuru after publishing.')
