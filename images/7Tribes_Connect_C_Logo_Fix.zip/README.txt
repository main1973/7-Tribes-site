CONNECT C LOGO FIX — 7Tribes website

Problem: Connect buttons and the shared navigation were using
https://connect.7trb.com/favicon.ico

Connect's own application header uses this C-logo image:
https://connect.7trb.com/manus-storage/connect-7tribes-icon_ebcb6f78.png

Correction: replace the old URL with the new URL in these existing files:
- index.html
- ecosystem.html
- js/unified-menu.js

From the ROOT of the 7-Tribes-site repository run:
    python3 apply_connect_c_logo_fix.py

Then commit/publish the three modified files to GitHub Pages.
Uploading this ZIP or the Python script into GitHub does NOT change the site.
You must execute the script or make the URL replacements in the three files.

No external script or login needs to change. The image is referenced directly
from Connect's public domain. Confirm it loads on Chrome/mobile after publish;
if not, copy the official logo PNG into the site's own /images/ directory and
update the URL to that local asset.
