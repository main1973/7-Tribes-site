#!/usr/bin/env python3
"""Use Connect's actual C brand icon in 7Tribes buttons and navigation.

Run from the root of the main1973/7-Tribes-site repository:

    python3 apply_connect_c_logo_fix.py

Updates only image-source URLs in index.html, ecosystem.html and
js/unified-menu.js. It does not modify destinations, auth, wallets, or payments.
"""
from pathlib import Path
import sys

OLD = 'https://connect.7trb.com/favicon.ico'
NEW = 'https://connect.7trb.com/manus-storage/connect-7tribes-icon_ebcb6f78.png'
FILES = ('index.html', 'ecosystem.html', 'js/unified-menu.js')

root = Path.cwd()
changes = {}
for rel in FILES:
    file = root / rel
    if not file.is_file():
        sys.exit(f'Cannot find {rel}. Run from the root of main1973/7-Tribes-site. Nothing changed.')
    source = file.read_text(encoding='utf-8')
    if OLD in source:
        changes[file] = source.replace(OLD, NEW)
    elif NEW not in source:
        sys.exit(f'No recognizable Connect logo reference in {rel}. Nothing changed. Inspect the current code first.')

if not changes:
    print('Already using the Connect C logo in all three files. No changes needed.')
    sys.exit(0)

# Validation occurs before any writes.
for file, revised in changes.items():
    if OLD in revised or NEW not in revised:
        sys.exit(f'Validation failed for {file}. Nothing changed.')

for file, revised in changes.items():
    file.write_text(revised, encoding='utf-8')
    print(f'Updated: {file.relative_to(root)}')
print('Connect buttons and shared navigation now point to Connect\'s own app logo.')
print('Commit and publish these source changes; uploading this script/ZIP alone will not apply them.')
